/**
 * Histogram that visually inspects the frequency
 * distribution of a set of values.
 * 
 * @author Donald Marovich
 * Sources: http://stackoverflow.com/questions/23699132/how-to-make-a-menu-until-user-inputs-to-exit
 * http://stackoverflow.com/questions/2426671/variable-length-dynamic-arrays-in-java
 * https://www.youtube.com/watch?v=KCH_ZDygrm4
 * 
 */
import java.util.*;


public class Marovich_A03Q3
{
 
    public static void main(String[] args) { 
        
        //Create our scan object to take input
        Scanner scan = new Scanner(System.in);
        
        //creates a list to store numbers in
        List<Integer> list = new ArrayList<Integer>();
        
        //create our variables and booleans used
        boolean game_on = true;
        int user_input, quit = 0;
        
        //create an array to store our historgram information
        int[] hist = new int[11];
        
        while (game_on == true) {
                System.out.print("Enter a value to plot: ");
                user_input = scan.nextInt();
                
                //Scans the user input to be 1-10
                if (user_input <= 10 && user_input > 0) {
                    
                    //adds the users input to the list
                    list.add(user_input);
                    
                    //goes through numbers 1-10 and if the user input and the number match
                    //it adds 1 to the corresponding space in hist array
                    for (int i = 1; i < 11; i++) {
                        if(user_input == i) {
                            hist[i] += 1;
                        }
                    }
                }
                
                //Scans if the user input was 0
                else if (user_input == quit) {
                    System.out.println("You have chosen to stop entering numbers.");
                    System.out.println("Your numbers are: " + list);
                    
                    //ends the prompting for numbers 
                    game_on = false;
                }
                
                //lets the user know to only input correct numbers
                else if (user_input > 10 || user_input < 0) {
                    System.out.println("Please enter 1-10 only and 0 to stop.");
                }
        }
        
        //runs a loop 10 times
        for (int i=1; i < 11; i++){
            
            //create our variables
            String hash = "#";
            String result = "";
            
            //Prints out the current number
            System.out.print(i + " | ");
                
                //For the current number do the following
                for (int j = 0; j < hist[i]; j++) {
                    
                    //print a hash until j is equal to the number stored in the array
                    System.out.print(hash);
                }
            
            //goes to the next line for the next number
            System.out.println();
        }
    }
    
    
        
}
