/**
 * Write a description of class Base_A03Q4 here.
 * 
 * @author (your name) 
 */
import java.util.*;

public class Base_A03Q4 {
    
    public static class RoundShape {
        double radius, height, area, volume;
        String name;
        
        public RoundShape(double r) {
            radius = r;
            //this.height = height;
        }
        
        public void setRadius(double r) {
            radius = r;
        }
        
        public double getRadius() {
            return radius;
        }
        
        public double getHeight() {
            return height;
        }
        
        public double getArea() {
            return area;
        }
        
        public double getVolume() {
            return volume; 
        }
        
        public String toString() {
            return ("Type: " + name + "\t" + "Radius: " + radius + "\t" + 
            "Height: " + height + "\t" + "Volume: " + this.getVolume() + "\t" +
            "Area: " + this.getArea());
        }
    }
    
    public static class Sphere extends RoundShape {
        
        public Sphere(double r) {
            super(r);
            this.radius = r;
            this.height = r + r;
            name = "Sphere";
        }
        
        public double getVolume() {
            volume = ((4.0/3.0)*Math.PI*(radius*radius*radius));
            return volume;
        }
        
        public double getArea() {
            area = (4.0*Math.PI*(radius*radius));
            return area;
        }
        /*
        public String toString() {
            return ("The volume of the SPHERE is: " + "\t" + getVolume() +
            "\n" + "The surface area is: " + "\t" + getSurfaceArea());
        }*/
    }
    
    public static class Cone extends RoundShape {
        
        public Cone(double r, double h) {
            super(r); 
            this.radius = r;
            this.height = h;
            name = "Cone";
        }
        
        public void setHeight(double h) {
            height = h;
        }
        
        public double getVolume() {
            volume = ((1.0/3.0)*Math.PI*(radius*radius)*height);
            return volume;
        }
        
        public double getArea() {
            area = (Math.PI*radius*(height+radius));
            return area;
        }
       /* 
        public String toString() {
            return ("The volume of the CONE is: " + "\t" + getVolume() +
            "\n" + "The surface area is: " + "\t" + getSurfaceArea());
        }*/
    }    
    
    public static void main(String[] args) {
           Sphere sphere1 = new Sphere(2.4);
           Sphere sphere2 = new Sphere(7);
           Cone cone1 = new Cone(13,7);
           Cone cone2 = new Cone(8,9);
           
           System.out.println(sphere1);
           System.out.println(sphere2);
           System.out.println(cone1);
           System.out.println(cone2);
           
           sphere1.setRadius(4);
           sphere2.setRadius(5);
           cone1.setRadius(36);
           cone2.setHeight(33);
           
           System.out.println(sphere1);
           System.out.println(sphere2);
           System.out.println(cone1);
           System.out.println(cone2);
    }
}